# WhatsApp Chatbot Simulation (Spring Boot)

## Run the project
1. Install Java + Maven
2. Run:
   mvn spring-boot:run

## Test API
POST http://localhost:8080/webhook

Body:
{
  "message": "hi"
}

Response:
{
  "reply": "Hello"
}
